#ifndef __REQUEST_H__
#include "stats.h"

void requestHandle(int fd, Stats *stats);

#endif
